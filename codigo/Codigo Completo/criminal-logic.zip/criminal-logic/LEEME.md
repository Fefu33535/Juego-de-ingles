# Criminal Logic

Juego web educativo: el jugador es detective y resuelve casos en inglés. En cada caso tiene que encontrar
al culpable y la contradicción de su testimonio.

**Creado por:** Ian Windholz, Federico Petrosini y Marco Antonio Flores Mujica.

## Cómo abrirlo

1. Descomprimí el ZIP.
2. Abrí `index.html` con doble clic. Funciona sin internet y sin servidor (también se puede subir a GitHub Pages).
3. Iniciá sesión con:
   - **Usuario:** `ejemplo@alu.bue.edu.ar`
   - **Contraseña:** `12345`

Para empezar de cero, andá a **Menú → ⓘ (Información) → REINICIAR TODO**.

---

## Estructura del proyecto

```
criminal-logic/
├── index.html            Inicio de sesión
├── menu.html             Menú principal (perfil con el saldo de Lupapoints)
├── selector.html         Selector de niveles (carpetas con candado)
├── nivel.html            Pantalla de juego: nivel.html?n=1, ?n=2, ?n=3
├── final.html            Evaluación final: nota y bonificación
├── tienda.html           Tienda de puntos
├── vestidor.html         Vestidor
├── instrucciones.html    Cómo se juega
├── info.html             Información, progreso y reinicio
│
├── css/
│   ├── base.css          Variables de color, tipografías, reset, estructura responsive
│   ├── componentes.css   Marcador de Lupapoints, botones, cartel (toast), ventana (modal), HUD con reloj
│   └── pantallas/        Un archivo por pantalla (menu.css, nivel.css, tienda.css…)
│
├── js/
│   ├── nucleo/           Lógica compartida (no dibuja nada)
│   │   ├── config.js         ← TODAS las reglas ajustables están acá
│   │   ├── almacenamiento.js Guardado seguro en el navegador
│   │   ├── sesion.js         Inicio y cierre de sesión
│   │   ├── lupapoints.js     Único sistema de puntos (niveles, bono final y tienda)
│   │   ├── progreso.js       Desbloqueo permanente de niveles
│   │   ├── partida.js        Errores, puntos por nivel y cálculo de la nota
│   │   └── cronometro.js     Reloj de cada nivel
│   ├── ui/               toast.js, modal.js, marcador.js
│   ├── niveles/          Motor de juego y datos de cada caso
│   │   ├── motor.js          Recorrido de pantallas, acusación, reloj, redirección
│   │   ├── dibujo-imagenes.js Pantallas ilustradas (nivel 1)
│   │   ├── dibujo-html.js    Pantallas armadas con HTML (niveles 2 y 3)
│   │   ├── casos.js          Registro de casos
│   │   └── nivel1.js · nivel2.js · nivel3.js   Datos de cada caso
│   └── pantallas/        Lógica propia de cada página
│
└── assets/
    ├── fonts/            Special Elite (máquina de escribir) + licencia
    └── images/
        ├── ui/           Moneda Lupapoint, botón SALIR común
        ├── sesion/  menu/  selector/  tienda/  vestidor/
        └── niveles/
            ├── comun/    Flechas, BACK, ACCUSE, RETRY, NEXT CASE, contradicciones, texturas
            ├── nivel1/   Pantallas ilustradas del caso 1
            ├── nivel2/   Retratos y foto del caso 2 (SVG)
            └── nivel3/   Retratos y foto del caso 3 (SVG)
```

Cada script empieza con un comentario que explica qué hace y cómo se usa.

---

## Reglas del juego

Todas se cambian desde `js/nucleo/config.js`.

| Regla | Valor | Variable en config.js |
|---|---|---|
| Tiempo por nivel | 10:00 (empieza en 0:00 y sube) | `TIEMPO_LIMITE_SEGUNDOS` |
| Lupapoints al resolver un caso | 5.000 | `PUNTOS_POR_NIVEL` |
| Saldo inicial | 1.200 | `PUNTOS_INICIALES` |
| Nota para aprobar | 7 | `NOTA_APROBACION` |
| Bono final | nota × 1.000 | `BONO_POR_PUNTO_DE_NOTA` |
| Segundos antes de volver solo al selector | 6 | `SEGUNDOS_REDIRECCION` |

**Cronómetro.** Está fijo en la esquina superior derecha de la pantalla de juego. Cada nivel tiene su
propio reloj. Recargar la página o volver atrás no lo reinicia. RETRY tampoco: el reloj sigue corriendo.
Al llegar a 10:00 aparece el sello *TIME'S UP* y el jugador va a la pantalla final.

**Al resolver un caso.** Se suman 5.000 Lupapoints y el caso siguiente se desbloquea para siempre.
Después de 6 segundos el jugador vuelve solo al selector (o antes, con NEXT CASE). Si es el último caso,
va a la evaluación final.

**Errores.** Cada acusación equivocada (sospechoso o contradicción incorrectos) suma un error.

**Pantalla final.** Se llega de tres formas: resolviendo el caso 3, por tiempo agotado o abandonando
con el botón ✕ junto al reloj.

| Situación | Nota | Bonificación |
|---|---|---|
| Resolvió los 3 casos con 3 errores o menos | 10 − errores (7 a 10) **APROBADO** | nota × 1.000 Lupapoints |
| Resolvió los 3 casos con 4 errores o más | 10 − errores (6 o menos) **DESAPROBADO** | ninguna |
| Tiempo agotado o abandono | 1 + casos resueltos en la partida **DESAPROBADO** | ninguna |

**Para que no se "farmeen" puntos para la tienda:**
- Repetir un caso ya cobrado no vuelve a pagar los 5.000. Para cambiarlo: `PUNTOS_SOLO_PRIMERA_VEZ: false`.
- El bono final se cobra una sola vez, en la primera partida aprobada. Para cambiarlo: `BONO_SOLO_UNA_VEZ: false`.

---

## Diseño responsive

- **Computadora y pantallas horizontales:** cada pantalla se ve completa, sin desplazamiento.
- **Nivel 1 (pantallas ilustradas):** la imagen mantiene su proporción 16:9 y los botones están en
  porcentajes, así nunca se desalinean. En un celular vertical aparece la sugerencia de girarlo.
- **Niveles 2 y 3, menú, tienda, vestidor, final:** en celulares y tablets en vertical, los elementos se
  apilan en una columna y la página se desplaza.
- Se usan `flexbox`, `grid`, `clamp()`, unidades `vw`/`vh`/`dvh`/`vmin`, *container queries* (en el
  armario) y media queries.

Se probó en 360×740, 390×844, 768×1024, 844×390, 1024×768, 1280×720, 1366×768, 1920×1080 y 2560×1080,
sin desbordes horizontales.

---

## Cómo modificar el juego

**Cambiar textos de un caso:** editá `js/niveles/nivel2.js` o `nivel3.js`. Ahí está todo: el glosario, el
expediente, los sospechosos, los testimonios, el culpable (`culpable`) y la contradicción correcta
(`contradiccionCorrecta`: `'ubicacion'` o `'arma'`).

**Usar tus propios dibujos en los casos 2 y 3:** poné la imagen en `assets/images/niveles/nivel2/` (por
ejemplo `henry.png`, con proporción vertical 200×260) y cambiá `retrato: 'henry-blackwood.svg'` por
`retrato: 'henry.png'`.

**Convertir el caso 2 o 3 en pantallas ilustradas como el nivel 1:** guardá las imágenes en la carpeta del
nivel con los mismos nombres que usa el nivel 1 (`glosario.jpg`, `testimonio-{id}.jpg`…) y copiá la forma
de `nivel1.js` (`tipo: 'imagenes'`).

**Ancho del tablero de la tienda:** cambiá la variable `--ancho-tablero` al principio de
`css/pantallas/tienda.css` (hoy: la mitad de la pantalla, entre 560 px y 760 px).

**Tamaño de los botones del menú:** `.menu-boton img` en `css/pantallas/menu.css`.

**Agregar un nivel 4:**
1. Copiá `nivel3.js` como `nivel4.js` y cambiá `Casos.registrar(3, …)` por `Casos.registrar(4, …)`.
2. Agregá `<script src="js/niveles/nivel4.js"></script>` en `nivel.html`.
3. En `config.js`, cambiá `TOTAL_NIVELES` a 4.
4. En `selector.html`, agregá una cuarta carpeta con `data-nivel="4"`.

---

## Qué se guarda en el navegador (localStorage)

| Clave | Contenido |
|---|---|
| `criminal_logic_sesion_activa`, `criminal_logic_usuario` | Sesión (las mismas que ya usaba el inicio de sesión) |
| `criminal_logic_lupapoints` | Saldo (la misma clave que ya usaba la tienda) |
| `criminal_logic_compras`, `criminal_logic_equipado` | Tienda y vestidor (sin cambios) |
| `criminal_logic_progreso` | Último nivel resuelto |
| `criminal_logic_niveles_cobrados`, `criminal_logic_bono_final_cobrado` | Puntos ya pagados |
| `criminal_logic_partida` | Partida en curso: errores, casos resueltos y hora de inicio de cada reloj |
| `criminal_logic_ultimo_resultado` | Lo que muestra la pantalla final |

---

## Cambios respecto del proyecto original

- Todas las páginas están en la misma carpeta y los nombres coinciden. Antes había enlaces a `menu.html`
  y `Menu.html` mezclados, el menú apuntaba a `jugar.html` y el selector se llamaba `SelectorDeNiveles.html`.
- Se crearon las páginas que el menú enlazaba y no existían: `instrucciones.html` e `info.html`.
  El botón SALIR del menú ahora cierra la sesión.
- El fondo del menú no cargaba (la ruta tenía otro nombre): corregido.
- Se eliminaron todos los `alert()`. Ahora hay carteles y ventanas propias con el estilo del juego.
- Las imágenes pasaron de unos 37 MB a 7 MB sin cambiar su aspecto: se achicaron los botones enormes
  (por ejemplo, `botonback.png` medía 2170 px) y el fondo del menú pasó de PNG a JPG. También se borró la
  copia duplicada `Pantalla_informacion_del_caso (1).jpg` y se corrigió el nombre `Panatalla_…`.
- La tienda y el vestidor mantienen su diseño, sus artículos, sus precios y sus claves de guardado.
  Ahora usan el sistema de puntos compartido y se adaptan al celular.
- `tienda/boton-comprar.png` y `tienda/boton-comprado.png` se conservaron, aunque la tienda original
  dibuja esos botones con CSS y no las usa.

---

## Soluciones (para el docente)

| Caso | Culpable | Contradicción | Por qué |
|---|---|---|---|
| 01 · The South Star Heist | James Hunter | LOCATION | (caso original del equipo) |
| 02 · Murder at Blackwood Manor | Henry Blackwood | MURDER WEAPON | Menciona el candelabro, pero la policía nunca contó qué objeto se usó. |
| 03 · Death on the Night Train | George Hale | LOCATION | Dice que estuvo en el vagón comedor hasta la medianoche, pero ese vagón se cerró con llave a las 10:45 PM. |
