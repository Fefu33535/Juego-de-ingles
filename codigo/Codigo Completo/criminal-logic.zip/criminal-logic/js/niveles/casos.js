/* =============================================================================
   casos.js — REGISTRO DE CASOS (NIVELES)
   -----------------------------------------------------------------------------
   Cada archivo de datos (nivel1.js, nivel2.js, nivel3.js) se anota acá con
   Casos.registrar(número, datos). El motor (motor.js) pide el caso que
   corresponde según la dirección: nivel.html?n=2 → Casos.obtener(2).

   PARA AGREGAR UN NIVEL NUEVO
     1. Copiá nivel2.js como nivel4.js y cambiá los textos e imágenes.
     2. Agregá <script src="js/niveles/nivel4.js"></script> en nivel.html.
     3. Subí CONFIG.TOTAL_NIVELES a 4 y sumá una carpeta en selector.html.
   ========================================================================== */

const Casos = (function () {
    'use strict';

    const registrados = {};

    function registrar(numero, datos) {
        registrados[numero] = Object.assign({ numero: numero }, datos);
    }

    function obtener(numero) {
        return registrados[numero] || null;
    }

    // Busca un sospechoso del caso por su id ('lucy', 'henry'...)
    function sospechoso(caso, id) {
        return caso.sospechosos.find(function (s) { return s.id === id; }) || null;
    }

    return { registrar, obtener, sospechoso };
})();
