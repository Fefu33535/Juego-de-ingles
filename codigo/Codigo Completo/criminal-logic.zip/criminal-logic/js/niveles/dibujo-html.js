/* =============================================================================
   dibujo-html.js — PANTALLAS DE LOS NIVELES ARMADOS CON HTML (niveles 2 y 3)
   -----------------------------------------------------------------------------
   Arma cada pantalla a partir de los datos del caso (nivel2.js, nivel3.js),
   con el mismo recorrido y los mismos botones que el nivel 1.
   El diseño está en css/pantallas/nivel.css:
     • pantalla grande y horizontal → composición fija 16:9, como el nivel 1
     • celular o tablet en vertical → las piezas se apilan y se desplaza
   ========================================================================== */

const DibujoHTML = (function () {
    'use strict';

    const COMUN = 'assets/images/niveles/comun/';

    // Evita que un texto de los datos se interprete como HTML
    function esc(texto) {
        return String(texto).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function imagenBoton(clase, accion, imagen, etiqueta, extra) {
        return '<button type="button" class="boton-imagen ' + clase + '" data-accion="' + accion + '" ' + (extra || '') + '>' +
            '<img src="' + COMUN + imagen + '" alt="' + esc(etiqueta) + '"></button>';
    }

    function flechas(anterior, siguiente) {
        return '<nav class="navegacion-caso" aria-label="Navegación del caso">' +
            (anterior ? imagenBoton('flecha flecha-anterior', 'anterior', 'flecha-izquierda.png', anterior) : '<span></span>') +
            (siguiente ? imagenBoton('flecha flecha-siguiente', 'siguiente', 'flecha-derecha.png', siguiente) : '<span></span>') +
            '</nav>';
    }

    // Etiqueta "CASE FILE 02 · CONFIDENTIAL"
    function etiquetaCaso(caso) {
        return '<div class="etiqueta-caso" aria-hidden="true">' +
            '<span class="etiqueta-caso-texto">CASE FILE</span>' +
            '<span class="etiqueta-caso-numero">' + esc(caso.expediente.numero) + '</span>' +
            '<span class="etiqueta-caso-sello">CONFIDENTIAL</span></div>';
    }

    function retrato(caso, s) {
        return '<img class="retrato" src="' + caso.carpeta + s.retrato + '" alt="Retrato de ' + esc(s.nombre) + '">';
    }

    function datosSospechoso(s) {
        return '<dl class="datos-sospechoso">' +
            '<div><dt>Age:</dt> <dd>' + esc(s.edad) + '</dd></div>' +
            '<div><dt>Occupation:</dt> <dd>' + esc(s.ocupacion) + '</dd></div>' +
            '<div><dt>Relationship to the case:</dt> <dd>' + esc(s.relacion) + '</dd></div>' +
            '</dl>';
    }

    // Ficha con chinche roja, retrato y nombre (contradicción y resultado)
    function fichaClavada(caso, s) {
        return '<figure class="ficha-clavada"><span class="chinche" aria-hidden="true"></span>' +
            retrato(caso, s) +
            '<figcaption class="placa-nombre">' + esc(s.nombre.toUpperCase()) + '</figcaption></figure>';
    }

    /* -------------------------------------------------------------------------
       PANTALLAS
       ---------------------------------------------------------------------- */
    function glosario(caso) {
        const filas = caso.glosario.map(function (par) {
            return '<div class="glosario-fila"><dt>' + esc(par[0]) + '</dt><dd>' + esc(par[1]) + '</dd></div>';
        }).join('');

        return '<div class="lienzo">' +
            etiquetaCaso(caso) +
            '<article class="hoja hoja-glosario">' +
            '<h1 class="hoja-titulo">GLOSSARY</h1>' +
            '<dl class="glosario">' + filas + '</dl>' +
            '</article>' +
            flechas(null, 'Siguiente: información del caso') +
            '</div>';
    }

    function informacion(caso) {
        const e = caso.expediente;
        const lista = function (items) {
            return '<ul>' + items.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>';
        };
        const mini = caso.sospechosos.map(function (s, i) {
            return '<li class="mini-tarjeta"><span class="mini-etiqueta">S' + (i + 1) + '</span>' +
                retrato(caso, s) + '<span class="mini-nombre">' + esc(s.nombre.toUpperCase()) + '</span></li>';
        }).join('');

        return '<div class="lienzo">' +
            '<article class="hoja hoja-expediente">' +
            '<header class="expediente-cabecera">' + etiquetaCaso(caso) +
            '<h1 class="titulo-caso">' + esc(caso.titulo) + '</h1></header>' +
            '<figure class="foto-caso"><img src="' + caso.carpeta + e.foto + '" alt="' + esc(e.epigrafe) + '">' +
            '<figcaption>' + esc(e.epigrafe) + '</figcaption></figure>' +
            '<section class="bloque bloque-contexto"><h2>CASE CONTEXT</h2>' +
            e.contexto.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + '</section>' +
            '<section class="bloque bloque-datos"><h2>KEY DETAILS</h2>' + lista(e.datosClave) + '</section>' +
            '<section class="bloque bloque-sospechosos"><h2>SUSPECTS</h2><ul class="mini-tarjetas">' + mini + '</ul></section>' +
            '<section class="bloque bloque-evidencias"><h2>EVIDENCE FOUND</h2>' + lista(e.evidencias) + '</section>' +
            '</article>' +
            flechas('Volver al glosario', 'Siguiente: elegir sospechoso') +
            '</div>';
    }

    function seleccion(caso) {
        const tarjetas = caso.sospechosos.map(function (s, i) {
            return '<button type="button" class="tarjeta-sospechoso" data-accion="elegir" data-sospechoso="' + s.id + '">' +
                '<span class="chinche" aria-hidden="true"></span>' +
                '<span class="tarjeta-etiqueta">S' + (i + 1) + '</span>' +
                retrato(caso, s) +
                '<span class="tarjeta-cuerpo">' +
                '<span class="tarjeta-nombre">' + esc(s.nombre.toUpperCase()) + '</span>' +
                '<span class="tarjeta-dato">Age: ' + esc(s.edad) + '</span>' +
                '<span class="tarjeta-dato">Occupation: ' + esc(s.ocupacion) + '</span>' +
                '<span class="tarjeta-dato">Relationship to the case: ' + esc(s.relacion) + '</span>' +
                '</span></button>';
        }).join('');

        return '<div class="lienzo">' +
            '<header class="cabecera-seleccion"><h1>SELECT A SUSPECT</h1>' +
            '<p>Choose who you want to investigate further.</p></header>' +
            '<div class="tarjetas-sospechosos">' + tarjetas + '</div>' +
            '<p class="nota-papel">Select a suspect to view more details and look for contradictions.</p>' +
            flechas('Volver a la información del caso', null) +
            '</div>';
    }

    function testimonio(caso, s) {
        return '<div class="lienzo">' +
            imagenBoton('boton-volver', 'volver-seleccion', 'boton-back.png', 'Volver a los sospechosos') +
            '<div class="libro">' +
            '<div class="pagina pagina-ficha">' +
            '<div class="ficha"><span class="clip" aria-hidden="true"></span>' + retrato(caso, s) + '</div>' +
            '<p class="placa-nombre placa-grande">' + esc(s.nombre.toUpperCase()) + '</p>' +
            datosSospechoso(s) +
            '</div>' +
            '<article class="pagina pagina-testimonio">' +
            '<h1 class="hoja-titulo">TESTIMONY</h1>' +
            '<div class="texto-testimonio">' +
            s.testimonio.map(function (p, i, todo) {
                // Comillas al principio y al final, como en el nivel 1
                const apertura = i === 0 ? '“' : '';
                const cierre = i === todo.length - 1 ? '”' : '';
                return '<p>' + apertura + esc(p) + cierre + '</p>';
            }).join('') +
            '</div></article>' +
            '</div>' +
            imagenBoton('boton-acusar', 'acusar', 'boton-accuse.png', 'Acusar a ' + s.nombre) +
            '</div>';
    }

    function contradiccion(caso, s) {
        return '<div class="lienzo">' +
            imagenBoton('boton-volver', 'volver-testimonio', 'boton-back.png', 'Volver al testimonio') +
            '<h1 class="cartel-pregunta">WHY DO YOU THINK HE/SHE IS GUILTY?</h1>' +
            fichaClavada(caso, s) +
            '<div class="opciones-contradiccion">' +
            imagenBoton('opcion-contradiccion', 'contradiccion', 'boton-contradiccion-ubicacion.jpg', 'Location contradiction', 'data-tipo="ubicacion"') +
            imagenBoton('opcion-contradiccion', 'contradiccion', 'boton-contradiccion-arma.jpg', 'Murder weapon contradiction', 'data-tipo="arma"') +
            '</div>' +
            '</div>';
    }

    function resultado(caso, s, estado) {
        const r = estado.resultado;
        const veredicto = function (texto, ok) {
            return '<p class="veredicto ' + (ok ? 'es-correcto' : 'es-incorrecto') + '">' + texto + ': ' + (ok ? 'CORRECT' : 'INCORRECT') + '</p>';
        };

        let extra = '';
        if (r.gano) {
            extra += r.puntos > 0
                ? '<p class="premio">+ ' + Lupapoints.formatear(r.puntos) + '<br>LUPAPOINTS</p>'
                : '<p class="premio premio-repetido">CASE ALREADY SOLVED<br><small>Los Lupapoints se cobran una sola vez.</small></p>';
            extra += '<p class="cierre-caso"><strong>CASE CLOSED.</strong> ' + esc(caso.cierre) + '</p>';
            extra += '<p class="aviso-redireccion" data-cuenta-regresiva aria-live="polite"></p>';
            extra += imagenBoton('boton-resultado', 'siguiente-caso', 'boton-next-case.png',
                r.esUltimo ? 'Ver la evaluación final' : 'Volver al selector de niveles');
        } else {
            extra += imagenBoton('boton-resultado', 'reintentar', 'boton-retry.png', 'Reintentar el caso');
        }

        return '<div class="lienzo">' +
            fichaClavada(caso, s) +
            '<div class="veredictos" role="status">' +
            veredicto('SUSPECT', r.sospechosoOk) +
            veredicto('CONTRADICTION', r.contradiccionOk) +
            '</div>' +
            extra +
            '</div>';
    }

    /* -------------------------------------------------------------------------
       PUNTO DE ENTRADA PARA EL MOTOR
       ---------------------------------------------------------------------- */
    function dibujar(pantalla, estado, caso) {
        const s = estado.sospechoso ? Casos.sospechoso(caso, estado.sospechoso) : null;
        switch (pantalla) {
            case 'glosario': return glosario(caso);
            case 'informacion': return informacion(caso);
            case 'seleccion': return seleccion(caso);
            case 'testimonio': return testimonio(caso, s);
            case 'contradiccion': return contradiccion(caso, s);
            case 'resultado': return resultado(caso, s, estado);
        }
        return '';
    }

    function imagenesParaPrecargar(caso) {
        const lista = [caso.carpeta + caso.expediente.foto, COMUN + 'papel.jpg', COMUN + 'tarjeta.jpg',
            COMUN + 'fondo-mesa.jpg', COMUN + 'corcho.jpg'];
        caso.sospechosos.forEach(function (s) { lista.push(caso.carpeta + s.retrato); });
        return lista;
    }

    return { dibujar, imagenesParaPrecargar };
})();
