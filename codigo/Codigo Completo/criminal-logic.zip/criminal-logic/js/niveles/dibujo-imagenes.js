/* =============================================================================
   dibujo-imagenes.js — PANTALLAS DE LOS NIVELES ILUSTRADOS (nivel 1)
   -----------------------------------------------------------------------------
   Cada pantalla es una imagen a pantalla completa (16:9) con botones
   transparentes ("zonas") encima. Las posiciones de las zonas están en
   css/pantallas/nivel.css, en porcentajes, como en el Nivel1.css original.

   El motor llama a DibujoImagenes.dibujar(pantalla, estado, caso) y recibe
   el HTML de la pantalla pedida.
   ========================================================================== */

const DibujoImagenes = (function () {
    'use strict';

    const COMUN = 'assets/images/niveles/comun/';

    // Arma la ruta de una imagen del caso: 'testimonio-{id}.jpg' → 'testimonio-james.jpg'
    function ruta(caso, clave, id, tipo) {
        return caso.carpeta + caso.imagenes[clave]
            .replace('{id}', id || '')
            .replace('{tipo}', tipo || '');
    }

    // Botón transparente con la imagen del botón original adentro
    function zona(clase, accion, imagen, etiqueta, atributosExtra) {
        return '<button type="button" class="zona ' + clase + '" data-accion="' + accion + '" ' +
            'aria-label="' + etiqueta + '" ' + (atributosExtra || '') + '>' +
            (imagen ? '<img src="' + COMUN + imagen + '" alt="">' : '') +
            '</button>';
    }

    function lienzo(imagen, textoAlternativo, contenido) {
        return '<div class="lienzo-imagen">' +
            '<img class="imagen-pantalla" src="' + imagen + '" alt="' + textoAlternativo + '">' +
            contenido +
            '</div>' +
            '<p class="aviso-girar">Girá el dispositivo para ver el caso más grande.</p>';
    }

    function dibujar(pantalla, estado, caso) {
        const id = estado.sospechoso;
        const sospechoso = id ? Casos.sospechoso(caso, id) : null;
        const nombre = sospechoso ? sospechoso.nombre : '';

        switch (pantalla) {

            case 'glosario':
                return lienzo(ruta(caso, 'glosario'), 'Glosario del caso',
                    zona('zona-flecha-derecha', 'siguiente', 'flecha-derecha.png', 'Siguiente: información del caso'));

            case 'informacion':
                return lienzo(ruta(caso, 'informacion'), 'Información del caso',
                    zona('zona-flecha-izquierda', 'anterior', 'flecha-izquierda.png', 'Volver al glosario') +
                    zona('zona-flecha-derecha', 'siguiente', 'flecha-derecha.png', 'Siguiente: elegir sospechoso'));

            case 'seleccion':
                return lienzo(ruta(caso, 'seleccion'), 'Elegí un sospechoso',
                    zona('zona-flecha-izquierda', 'anterior', 'flecha-izquierda.png', 'Volver a la información del caso') +
                    caso.sospechosos.map(function (s) {
                        // La posición horizontal de cada tarjeta viene de los datos del caso
                        return zona('zona-sospechoso', 'elegir', null, 'Investigar a ' + s.nombre,
                            'data-sospechoso="' + s.id + '" style="left:' + s.zona.left + '%;width:' + s.zona.width + '%"');
                    }).join(''));

            case 'testimonio':
                return lienzo(ruta(caso, 'testimonio', id), 'Testimonio de ' + nombre,
                    zona('zona-volver', 'volver-seleccion', 'boton-back.png', 'Volver a los sospechosos') +
                    zona('zona-acusar', 'acusar', 'boton-accuse.png', 'Acusar a ' + nombre));

            case 'contradiccion':
                return lienzo(ruta(caso, 'contradiccion', id), '¿Por qué ' + nombre + ' es culpable?',
                    zona('zona-volver', 'volver-testimonio', 'boton-back.png', 'Volver al testimonio') +
                    zona('zona-contradiccion zona-ubicacion', 'contradiccion', 'boton-contradiccion-ubicacion.jpg',
                        'Contradicción de ubicación', 'data-tipo="ubicacion"') +
                    zona('zona-contradiccion zona-arma', 'contradiccion', 'boton-contradiccion-arma.jpg',
                        'Contradicción del arma', 'data-tipo="arma"'));

            case 'resultado': {
                const r = estado.resultado;
                const boton = r.gano
                    ? zona('zona-resultado', 'siguiente-caso', 'boton-next-case.png', r.esUltimo ? 'Ver la evaluación final' : 'Volver al selector de niveles')
                    : zona('zona-resultado', 'reintentar', 'boton-retry.png', 'Reintentar el caso');
                // La imagen de victoria ya trae dibujado "+ 5000 LUPAPOINTS".
                // Si el caso se repite y no paga, se aclara con un cartel.
                const avisos = r.gano
                    ? (r.puntos === 0 ? '<p class="nota-repetido">Caso ya resuelto antes: los Lupapoints se cobran una sola vez.</p>' : '') +
                      '<p class="aviso-redireccion" data-cuenta-regresiva aria-live="polite"></p>'
                    : '';
                return lienzo(ruta(caso, 'resultado', id, estado.contradiccion), 'Resultado de la acusación', boton + avisos);
            }
        }
        return '';
    }

    // Todas las imágenes del caso, para descargarlas antes de que se necesiten
    function imagenesParaPrecargar(caso) {
        const lista = [ruta(caso, 'glosario'), ruta(caso, 'informacion'), ruta(caso, 'seleccion')];
        caso.sospechosos.forEach(function (s) {
            lista.push(ruta(caso, 'testimonio', s.id), ruta(caso, 'contradiccion', s.id),
                ruta(caso, 'resultado', s.id, 'ubicacion'), ruta(caso, 'resultado', s.id, 'arma'));
        });
        ['flecha-derecha.png', 'flecha-izquierda.png', 'boton-back.png', 'boton-accuse.png', 'boton-retry.png',
            'boton-next-case.png', 'boton-contradiccion-ubicacion.jpg', 'boton-contradiccion-arma.jpg']
            .forEach(function (archivo) { lista.push(COMUN + archivo); });
        return lista;
    }

    return { dibujar, imagenesParaPrecargar };
})();
