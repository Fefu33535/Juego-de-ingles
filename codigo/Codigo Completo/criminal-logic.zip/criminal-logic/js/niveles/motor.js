/* =============================================================================
   motor.js — MOTOR DE LOS NIVELES (nivel.html?n=1, 2 o 3)
   -----------------------------------------------------------------------------
   Un solo motor para todos los casos. Se encarga de:
     1. Elegir el caso según la dirección (?n=2 → caso 2)
     2. Recorrer las pantallas:
          glosario → informacion → seleccion → testimonio → contradiccion → resultado
     3. Decidir si la acusación es correcta
     4. Manejar el cronómetro (esquina superior derecha)
     5. Pagar los Lupapoints, desbloquear el siguiente nivel y volver al selector

   Cómo se dibuja cada pantalla lo deciden:
     DibujoImagenes → casos ilustrados (nivel 1)
     DibujoHTML     → casos armados con HTML (niveles 2 y 3)
   ========================================================================== */

(function () {
    'use strict';

    /* -------------------------------------------------------------------------
       1. QUÉ NIVEL SE JUEGA
       ---------------------------------------------------------------------- */
    const numero = parseInt(new URLSearchParams(window.location.search).get('n'), 10) || 1;
    const caso = Casos.obtener(numero);

    if (!caso) {
        window.location.replace(CONFIG.RUTAS.selector);
        return;
    }
    if (!Progreso.exigirDesbloqueo(numero)) {
        return;                               // nivel bloqueado: vuelve al selector
    }

    const dibujante = caso.tipo === 'imagenes' ? DibujoImagenes : DibujoHTML;
    const escenario = document.getElementById('escenario');

    document.title = 'Caso ' + String(numero).padStart(2, '0') + ': ' + caso.titulo + ' - Criminal Logic';
    document.querySelector('[data-hud-caso]').textContent = 'CASO ' + numero;

    /* -------------------------------------------------------------------------
       2. ESTADO DEL NIVEL (solo dura mientras la página está abierta)
       ---------------------------------------------------------------------- */
    const ORDEN_INICIAL = ['glosario', 'informacion', 'seleccion'];

    const estado = {
        pantalla: 'glosario',
        sospechoso: null,       // id del sospechoso elegido
        contradiccion: null,    // 'ubicacion' o 'arma'
        resultado: null,        // { sospechosoOk, contradiccionOk, gano, puntos, esUltimo }
        terminado: false        // true cuando ya no se puede seguir jugando
    };

    let cuentaRegresiva = null;

    /* -------------------------------------------------------------------------
       3. MOSTRAR PANTALLAS
       ---------------------------------------------------------------------- */
    function mostrar(pantalla) {
        estado.pantalla = pantalla;
        escenario.className = 'escenario escenario-' + caso.tipo + ' en-' + pantalla;
        escenario.innerHTML = dibujante.dibujar(pantalla, estado, caso);
        window.scrollTo(0, 0);

        // Para teclado y lectores de pantalla: el foco vuelve al principio de la pantalla
        escenario.focus({ preventScroll: true });
    }

    /* -------------------------------------------------------------------------
       4. ACUSACIÓN
       ---------------------------------------------------------------------- */
    function acusar(tipoContradiccion) {
        if (estado.terminado) {
            return;
        }
        estado.contradiccion = tipoContradiccion;

        const sospechosoOk = estado.sospechoso === caso.culpable;
        const contradiccionOk = tipoContradiccion === caso.contradiccionCorrecta;
        const gano = sospechosoOk && contradiccionOk;

        estado.resultado = { sospechosoOk, contradiccionOk, gano, puntos: 0, esUltimo: false };

        if (gano) {
            // Detiene el reloj, desbloquea el siguiente nivel y paga los 5000
            const pago = Partida.resolverNivel(numero);
            estado.resultado.puntos = pago.puntos;
            estado.resultado.esUltimo = pago.esUltimo;
            terminarNivel();

            // Último caso: la partida termina y se evalúa ya mismo
            if (pago.esUltimo) {
                Partida.terminar('completado', numero);
            }
            mostrar('resultado');
            iniciarCuentaRegresiva();
        } else {
            Partida.registrarError(numero);
            mostrar('resultado');
        }
    }

    // Después de ganar: al selector, o a la evaluación si era el último caso
    function irDespuesDeGanar() {
        window.clearInterval(cuentaRegresiva);
        window.location.href = estado.resultado.esUltimo ? CONFIG.RUTAS.final : CONFIG.RUTAS.selector;
    }

    function iniciarCuentaRegresiva() {
        let restantes = CONFIG.SEGUNDOS_REDIRECCION;
        const destino = estado.resultado.esUltimo ? 'Viendo tu evaluación final' : 'Volviendo al selector de niveles';

        function escribir() {
            const aviso = escenario.querySelector('[data-cuenta-regresiva]');
            if (aviso) {
                aviso.textContent = destino + ' en ' + restantes + ' s…';
            }
        }
        escribir();
        cuentaRegresiva = window.setInterval(function () {
            restantes -= 1;
            if (restantes <= 0) {
                irDespuesDeGanar();
            } else {
                escribir();
            }
        }, 1000);
    }

    /* -------------------------------------------------------------------------
       5. FIN DEL NIVEL POR TIEMPO O ABANDONO
       ---------------------------------------------------------------------- */
    function terminarNivel() {
        estado.terminado = true;
        Cronometro.detener();
        document.querySelector('[data-accion="abandonar"]').hidden = true;
    }

    function tiempoAgotado() {
        if (estado.terminado) {
            return;
        }
        terminarNivel();
        Partida.terminar('tiempo', numero);

        // Cartel "TIEMPO AGOTADO" y, enseguida, la pantalla final
        document.getElementById('capa-tiempo').hidden = false;
        window.setTimeout(function () {
            window.location.replace(CONFIG.RUTAS.final);
        }, 2500);
    }

    function abandonar() {
        Modal.confirmar({
            titulo: '¿Abandonar el caso?',
            mensaje: 'La partida termina ahora y se evalúa tu desempeño. Un caso sin resolver no suma Lupapoints y baja la nota.',
            aceptar: 'ABANDONAR',
            cancelar: 'SEGUIR INVESTIGANDO'
        }).then(function (acepto) {
            if (acepto && !estado.terminado) {
                terminarNivel();
                Partida.terminar('abandono', numero);
                window.location.href = CONFIG.RUTAS.final;
            }
        });
    }

    /* -------------------------------------------------------------------------
       6. BOTONES: un solo manejador para todos (atributo data-accion)
       ---------------------------------------------------------------------- */
    const acciones = {
        siguiente: function () {
            const i = ORDEN_INICIAL.indexOf(estado.pantalla);
            mostrar(ORDEN_INICIAL[Math.min(i + 1, ORDEN_INICIAL.length - 1)]);
        },
        anterior: function () {
            const i = ORDEN_INICIAL.indexOf(estado.pantalla);
            mostrar(ORDEN_INICIAL[Math.max(i - 1, 0)]);
        },
        elegir: function (boton) {
            estado.sospechoso = boton.dataset.sospechoso;
            mostrar('testimonio');
        },
        'volver-seleccion': function () { mostrar('seleccion'); },
        acusar: function () { mostrar('contradiccion'); },
        'volver-testimonio': function () { mostrar('testimonio'); },
        contradiccion: function (boton) { acusar(boton.dataset.tipo); },
        reintentar: function () {
            // RETRY: vuelve al glosario. El reloj del nivel sigue corriendo.
            estado.sospechoso = null;
            estado.contradiccion = null;
            estado.resultado = null;
            mostrar('glosario');
        },
        'siguiente-caso': irDespuesDeGanar,
        abandonar: abandonar
    };

    document.addEventListener('click', function (evento) {
        const boton = evento.target.closest('[data-accion]');
        if (!boton || !acciones[boton.dataset.accion]) {
            return;
        }
        // Con el nivel terminado (tiempo agotado o abandono) ya no se puede jugar;
        // solo después de ganar sigue funcionando el botón NEXT CASE.
        if (estado.terminado && !(estado.resultado && estado.resultado.gano)) {
            return;
        }
        acciones[boton.dataset.accion](boton);
    });

    /* -------------------------------------------------------------------------
       7. ARRANQUE
       ---------------------------------------------------------------------- */
    // Descarga anticipada de las imágenes del caso (los cambios de pantalla son instantáneos)
    dibujante.imagenesParaPrecargar(caso).forEach(function (src) {
        const imagen = new Image();
        imagen.src = src;
    });

    Partida.empezarNivel(numero);          // arranca el reloj (o lo retoma si se recargó)
    mostrar('glosario');

    Cronometro.iniciar({
        elemento: document.querySelector('.hud-reloj'),
        obtenerSegundos: function () { return Partida.segundosNivel(numero); },
        limite: CONFIG.TIEMPO_LIMITE_SEGUNDOS,
        alAgotarse: tiempoAgotado
    });

    // Si el navegador restaura la página desde la caché (botón Atrás), se recarga
    // para que el estado del reloj y de la partida sea el real.
    window.addEventListener('pageshow', function (evento) {
        if (evento.persisted) {
            window.location.reload();
        }
    });
})();
