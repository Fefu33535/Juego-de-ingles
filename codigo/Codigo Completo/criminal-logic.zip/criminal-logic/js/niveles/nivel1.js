/* =============================================================================
   nivel1.js — CASO 01: THE SOUTH STAR HEIST
   -----------------------------------------------------------------------------
   Nivel hecho con las pantallas ilustradas originales (tipo 'imagenes').
   Cada pantalla es una imagen y los botones son zonas de clic ubicadas
   en porcentajes, así nunca se desalinean al cambiar el tamaño de la ventana.

   Las imágenes están en assets/images/niveles/nivel1/ y siguen esta regla
   de nombres ({id} = lucy, daniel o james; {tipo} = ubicacion o arma):
     testimonio-{id}.jpg · contradiccion-{id}.jpg · resultado-{id}-{tipo}.jpg
   ========================================================================== */

Casos.registrar(1, {
    tipo: 'imagenes',
    titulo: 'THE SOUTH STAR HEIST',
    carpeta: 'assets/images/niveles/nivel1/',

    // Respuesta correcta
    culpable: 'james',
    contradiccionCorrecta: 'ubicacion',      // 'ubicacion' (LOCATION) o 'arma' (MURDER WEAPON)

    // "zona": dónde está la tarjeta de cada sospechoso en la pantalla de selección
    // (left y width en % del ancho de la imagen)
    sospechosos: [
        { id: 'lucy',   nombre: 'Lucy Stone',   zona: { left: 24.5, width: 16.2 } },
        { id: 'daniel', nombre: 'Daniel Black', zona: { left: 41.8, width: 16.2 } },
        { id: 'james',  nombre: 'James Hunter', zona: { left: 58.8, width: 16.2 } }
    ],

    imagenes: {
        glosario: 'glosario.jpg',
        informacion: 'informacion-caso.jpg',
        seleccion: 'seleccion-sospechoso.jpg',
        testimonio: 'testimonio-{id}.jpg',
        contradiccion: 'contradiccion-{id}.jpg',
        resultado: 'resultado-{id}-{tipo}.jpg'
    }
});
