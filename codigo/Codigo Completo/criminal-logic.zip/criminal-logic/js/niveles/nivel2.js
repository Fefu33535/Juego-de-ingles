/* =============================================================================
   nivel2.js — CASO 02: MURDER AT BLACKWOOD MANOR
   -----------------------------------------------------------------------------
   Nivel armado con HTML y CSS (tipo 'html'): las pantallas se dibujan a
   partir de estos datos, con el mismo recorrido que el caso 1:
   glosario → expediente → elegir sospechoso → testimonio → contradicción → resultado.

   Para cambiar un retrato, reemplazá el archivo .svg de
   assets/images/niveles/nivel2/ por una imagen tuya (.png o .jpg) y
   actualizá el nombre en "retrato".

   SOLUCIÓN (no se la cuentes a los jugadores):
   Henry menciona el candelabro, pero la policía nunca compartió ese dato.
   Culpable: henry · Contradicción: arma (MURDER WEAPON)
   ========================================================================== */

Casos.registrar(2, {
    tipo: 'html',
    titulo: 'MURDER AT BLACKWOOD MANOR',
    carpeta: 'assets/images/niveles/nivel2/',

    culpable: 'henry',
    contradiccionCorrecta: 'arma',

    // Frase que se muestra al resolver el caso
    cierre: 'Henry talked about the candlestick, but the police never shared that information. Only the killer could know it.',

    glosario: [
        ['Manor', 'Casa señorial de campo; una mansión antigua.'],
        ['Butler', 'Mayordomo: el empleado principal de una casa.'],
        ['Candlestick', 'Candelabro: soporte de metal para una vela.'],
        ['Nephew', 'Sobrino (el hijo de tu hermano o hermana).'],
        ['Fountain', 'Fuente de agua, por ejemplo en un jardín.'],
        ['Wiped clean', 'Limpiado frotando, sin dejar huellas.'],
        ['To share', 'Compartir; contar una información a otras personas.'],
        ['Heavy', 'Pesado.']
    ],

    expediente: {
        numero: '02',
        foto: 'foto-mansion.svg',
        epigrafe: 'Blackwood Manor',
        contexto: [
            'Last Saturday, Lord Edgar Blackwood celebrated his 70th birthday with a dinner party at Blackwood Manor.',
            'After dinner, at about 9:45 PM, Lord Blackwood went to the library to rest. At 10:15 PM, the butler found him dead on the library floor. Someone had hit him on the head with a heavy object.',
            'The police arrived at 10:40 PM. They told the guests that Lord Blackwood was hit on the head, but they did not say which object was used.'
        ],
        datosClave: [
            'Time of the crime: between 9:50 PM and 10:15 PM.',
            'Location: Blackwood Manor — the library.',
            'People in the house: 12 guests and 4 staff.',
            'The library window was closed and locked from inside.',
            'Shared with the guests: only that the victim was hit on the head.'
        ],
        evidencias: [
            'A bronze candlestick disappeared from the dining room table after dinner.',
            'At 11:00 PM, the police found the candlestick in the garden fountain, wiped clean.',
            'The police did NOT share the candlestick information with anyone.',
            'Piano music was heard in the music room from 9:45 to 10:20 PM.',
            'A playing card (the queen of hearts) was on the library floor.'
        ]
    },

    sospechosos: [
        {
            id: 'margaret',
            nombre: 'Margaret Blackwood',
            edad: 45,
            ocupacion: 'Pianist',
            relacion: "Victim's daughter",
            retrato: 'margaret-blackwood.svg',
            testimonio: [
                'I loved my father. Yes, we argued about money last month, but every family has problems.',
                'After dinner, the guests asked me to play the piano. From 9:45 to 10:20 PM I played in the music room. Everybody in that room listened to me.',
                'When I finished, I heard the butler shouting. I ran to the library with the other guests and I saw my father on the floor.',
                "The police haven't told us exactly what happened. I only know that someone hit him on the head. Please, find the person who did this."
            ]
        },
        {
            id: 'henry',
            nombre: 'Henry Blackwood',
            edad: 29,
            ocupacion: 'Banker',
            relacion: "Victim's nephew",
            retrato: 'henry-blackwood.svg',
            testimonio: [
                'My uncle and I were very close. He was like a father to me.',
                "After dinner I stayed in the living room with the other guests. We played cards all evening. Well, at about 10 PM I left for a few minutes to get a drink from the dining room, but that's normal at a party.",
                'Then I came back to the living room and continued playing. Later, we heard the butler shouting.',
                "Why are you looking at me? Do you really think I could hit my uncle with a candlestick? That's ridiculous. I'm a gentleman, detective."
            ]
        },
        {
            id: 'victor',
            nombre: 'Victor Crane',
            edad: 62,
            ocupacion: 'Doctor',
            relacion: 'Family doctor and friend',
            retrato: 'victor-crane.svg',
            testimonio: [
                "I have been Edgar's doctor for thirty years. He was my best friend.",
                'At about 9:50 PM I went out to the garden terrace to get some fresh air. It was raining, so I stayed under the roof. Nobody was with me, I admit it.',
                'I came back inside at about 10:10 PM and went to the living room. A few minutes later, we heard the butler.',
                "I examined Edgar in the library. Someone hit him on the head very hard. I don't know who could do such a terrible thing."
            ]
        }
    ]
});
