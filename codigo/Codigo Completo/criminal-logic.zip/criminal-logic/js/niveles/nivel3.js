/* =============================================================================
   nivel3.js — CASO 03: DEATH ON THE NIGHT TRAIN
   -----------------------------------------------------------------------------
   Nivel armado con HTML y CSS (tipo 'html'), igual que el caso 2.
   Las imágenes están en assets/images/niveles/nivel3/.

   SOLUCIÓN (no se la cuentes a los jugadores):
   George dice que estuvo en el vagón comedor hasta la medianoche, pero el
   vagón comedor cerró con llave a las 10:45 PM.
   Culpable: george · Contradicción: ubicacion (LOCATION)
   ========================================================================== */

Casos.registrar(3, {
    tipo: 'html',
    titulo: 'DEATH ON THE NIGHT TRAIN',
    carpeta: 'assets/images/niveles/nivel3/',

    culpable: 'george',
    contradiccionCorrecta: 'ubicacion',

    cierre: 'George said he was in the dining car until midnight, but the dining car was closed and locked at 10:45 PM.',

    glosario: [
        ['Car', 'Vagón de un tren.'],
        ['Compartment', 'Compartimento: pequeña habitación privada dentro de un vagón.'],
        ['Dining car', 'Vagón comedor.'],
        ['Conductor', 'Guarda o revisor del tren.'],
        ['Letter opener', 'Abrecartas: cuchillo pequeño para abrir sobres.'],
        ['Business partner', 'Socio de negocios.'],
        ['Locked', 'Cerrado con llave.'],
        ['To knock', 'Golpear una puerta para llamar.']
    ],

    expediente: {
        numero: '03',
        foto: 'foto-tren.svg',
        epigrafe: 'The Northern Star',
        contexto: [
            'On Friday night, the Northern Star train left London at 10:00 PM. It travels all night to Edinburgh.',
            'At 11:40 PM, the conductor found Mr. Harold Finch, a rich banker, dead in his private compartment in Car 3. He was killed with his own silver letter opener.',
            'The train did not stop between 10:00 PM and 12:30 AM, so the killer is still on the train.'
        ],
        datosClave: [
            'Time of the crime: between 11:00 PM and 11:20 PM.',
            'Location: compartment 7, Car 3.',
            'The train did not stop until 12:30 AM.',
            'At 11:50 PM, the conductor told all the passengers what happened, including the letter opener.'
        ],
        evidencias: [
            'The dining car (Car 5) closed at 10:45 PM. The waiter locked the door and kept the key.',
            'The letter opener was found under a seat in Car 3.',
            "Two cups of tea on Mr. Finch's table. One cup has lipstick on it.",
            "Mr. Finch's diary: \"Meeting with G. at 11:00 PM — the money problem.\""
        ]
    },

    sospechosos: [
        {
            id: 'george',
            nombre: 'George Hale',
            edad: 51,
            ocupacion: 'Businessman',
            relacion: "Victim's business partner",
            retrato: 'george-hale.svg',
            testimonio: [
                'Harold and I were business partners for twenty years. We had some problems with money, but nothing serious.',
                'At 10:30 PM I went to the dining car, Car 5. I sat there alone, drinking tea and reading the newspaper until midnight.',
                'I never left the dining car, so I could not be in Car 3 at 11 PM. Ask the waiter, he will remember me.',
                'I am very sad. Harold was a difficult man, but he was my friend.'
            ]
        },
        {
            id: 'clara',
            nombre: 'Clara Moon',
            edad: 34,
            ocupacion: 'Actress',
            relacion: "Victim's ex-wife",
            retrato: 'clara-moon.svg',
            testimonio: [
                'Harold and I divorced five years ago, but we were still friends.',
                'Yes, I visited him at 10:30 PM. We had a cup of tea and talked about old times. The lipstick on that cup is mine, of course.',
                'I left his compartment at 10:50 PM and went back to my compartment in Car 2. I was reading until the conductor knocked on my door.',
                'The conductor told us that Harold was killed with his own letter opener. How horrible! He loved that silver letter opener.'
            ]
        },
        {
            id: 'samuel',
            nombre: 'Samuel Reed',
            edad: 27,
            ocupacion: 'Assistant',
            relacion: "Mr. Finch's assistant",
            retrato: 'samuel-reed.svg',
            testimonio: [
                'Mr. Finch was a difficult boss. Yesterday he shouted at me and said I could lose my job.',
                "But I didn't hurt him! I was very tired, so at 10:30 PM I went to sleep in my compartment in Car 4.",
                "I sleep like a stone. I didn't hear anything until the conductor knocked on my door at 11:50.",
                "Look, I'm still wearing my pajamas! I didn't have time to change."
            ]
        }
    ]
});
