/* =============================================================================
   almacenamiento.js — GUARDADO SEGURO EN EL NAVEGADOR
   -----------------------------------------------------------------------------
   El juego pasa de una página HTML a otra (menú → selector → nivel...).
   En cada cambio se borran las variables de JavaScript, por eso todo lo que
   tiene que sobrevivir (puntos, progreso, partida) se guarda en localStorage.

   Algunos navegadores bloquean localStorage (modo privado, archivos abiertos
   con ciertas restricciones). En ese caso se usa un respaldo en memoria para
   que el juego siga funcionando, aunque no se conserve al recargar.

   USO
     Almacen.leerTexto(clave)            → texto o null
     Almacen.guardarTexto(clave, texto)
     Almacen.leerNumero(clave, porDefecto)
     Almacen.leerJSON(clave, porDefecto) → objeto / lista
     Almacen.guardarJSON(clave, valor)
     Almacen.borrar(clave)
   ========================================================================== */

const Almacen = (function () {
    'use strict';

    const respaldo = {};          // se usa solo si localStorage falla
    let avisoMostrado = false;

    function avisarUnaVez() {
        if (!avisoMostrado) {
            avisoMostrado = true;
            console.warn('[Almacen] localStorage no disponible: los datos no se conservarán al recargar.');
        }
    }

    function leerTexto(clave) {
        try {
            return localStorage.getItem(clave);
        } catch (error) {
            avisarUnaVez();
            return Object.prototype.hasOwnProperty.call(respaldo, clave) ? respaldo[clave] : null;
        }
    }

    function guardarTexto(clave, texto) {
        try {
            localStorage.setItem(clave, String(texto));
        } catch (error) {
            avisarUnaVez();
            respaldo[clave] = String(texto);
        }
    }

    function borrar(clave) {
        try {
            localStorage.removeItem(clave);
        } catch (error) {
            delete respaldo[clave];
        }
    }

    function leerNumero(clave, porDefecto) {
        const numero = parseInt(leerTexto(clave), 10);
        return Number.isFinite(numero) ? numero : porDefecto;
    }

    function leerJSON(clave, porDefecto) {
        const texto = leerTexto(clave);
        if (texto === null) {
            return porDefecto;
        }
        try {
            return JSON.parse(texto);
        } catch (error) {
            // Dato dañado (por ejemplo, editado a mano): se ignora
            return porDefecto;
        }
    }

    function guardarJSON(clave, valor) {
        guardarTexto(clave, JSON.stringify(valor));
    }

    return { leerTexto, guardarTexto, leerNumero, leerJSON, guardarJSON, borrar };
})();
