/* =============================================================================
   config.js — CONFIGURACIÓN GENERAL DE CRIMINAL LOGIC
   -----------------------------------------------------------------------------
   Todos los valores que se pueden ajustar del juego están en este archivo:
   tiempos, puntos, reglas de la nota, nombres de páginas y claves de guardado.
   Si querés cambiar una regla, cambiala acá y no en cada pantalla.

   Este archivo se carga PRIMERO en todas las páginas.
   ========================================================================== */

const CONFIG = Object.freeze({

    /* ---------------------------------------------------------------------
       CRONÓMETRO
       Cada nivel tiene su propio reloj: arranca en 0:00 y cuenta hacia
       arriba. Al llegar al límite, la partida termina y se evalúa.
       ------------------------------------------------------------------ */
    TIEMPO_LIMITE_SEGUNDOS: 10 * 60,     // 10:00 por nivel
    AVISO_ULTIMOS_SEGUNDOS: 60,          // el reloj se pone rojo en el último minuto

    /* ---------------------------------------------------------------------
       LUPAPOINTS
       ------------------------------------------------------------------ */
    PUNTOS_INICIALES: 1200,              // saldo de un jugador nuevo (igual que la tienda original)
    PUNTOS_POR_NIVEL: 5000,              // bonificación por resolver un caso
    PUNTOS_SOLO_PRIMERA_VEZ: true,       // true: repetir un caso ya resuelto no vuelve a pagar
                                         // (evita "farmear" puntos para la tienda)

    /* ---------------------------------------------------------------------
       EVALUACIÓN DE LA PANTALLA FINAL
       Si resolvió los 3 casos:  nota = 10 − errores (mínimo 1)
       Si se le acabó el tiempo o abandonó: nota = 1 + casos resueltos
       en la partida (nunca llega a aprobar).
       Aprobado (nota ≥ NOTA_APROBACION) → bono = nota × BONO_POR_PUNTO_DE_NOTA
       ------------------------------------------------------------------ */
    NOTA_MAXIMA: 10,
    NOTA_APROBACION: 7,                  // cambialo a 6 si tu escuela aprueba con 6
    BONO_POR_PUNTO_DE_NOTA: 1000,        // nota 10 → 10.000 Lupapoints
    BONO_SOLO_UNA_VEZ: true,             // el bono final se cobra en la primera partida aprobada

    /* ---------------------------------------------------------------------
       NIVELES
       ------------------------------------------------------------------ */
    TOTAL_NIVELES: 3,
    SEGUNDOS_REDIRECCION: 6,             // tras ganar, vuelve solo al selector

    /* ---------------------------------------------------------------------
       PÁGINAS (si renombrás un archivo .html, cambialo solo acá)
       ------------------------------------------------------------------ */
    RUTAS: Object.freeze({
        inicio: 'index.html',
        menu: 'menu.html',
        selector: 'selector.html',
        nivel: 'nivel.html',             // se abre como nivel.html?n=1, ?n=2, ?n=3
        final: 'final.html',
        tienda: 'tienda.html',
        vestidor: 'vestidor.html',
        instrucciones: 'instrucciones.html',
        info: 'info.html'
    }),

    /* ---------------------------------------------------------------------
       CLAVES DE localStorage
       Las de sesión, Lupapoints, compras y vestuario son las mismas que ya
       usaban la tienda y el vestidor: no se pierde nada de lo guardado.
       ------------------------------------------------------------------ */
    CLAVES: Object.freeze({
        SESION_ACTIVA: 'criminal_logic_sesion_activa',
        USUARIO: 'criminal_logic_usuario',
        LUPAPOINTS: 'criminal_logic_lupapoints',
        COMPRAS: 'criminal_logic_compras',
        EQUIPADO: 'criminal_logic_equipado',
        PROGRESO: 'criminal_logic_progreso',               // último nivel resuelto (0 = ninguno)
        NIVELES_COBRADOS: 'criminal_logic_niveles_cobrados', // niveles que ya pagaron sus 5000
        BONO_COBRADO: 'criminal_logic_bono_final_cobrado',
        PARTIDA: 'criminal_logic_partida',                 // partida en curso
        RESULTADO: 'criminal_logic_ultimo_resultado'       // lo que muestra final.html
    })
});
