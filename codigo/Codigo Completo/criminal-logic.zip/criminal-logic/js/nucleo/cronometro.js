/* =============================================================================
   cronometro.js — RELOJ DE CADA NIVEL (esquina superior derecha)
   -----------------------------------------------------------------------------
   Muestra el tiempo en formato m:ss, empezando en 0:00 y contando hacia
   arriba. No guarda el tiempo por su cuenta: se lo pregunta a la partida
   (Partida.segundosNivel), así recargar la página no lo reinicia.

   Cuando llega al límite llama a la función "alAgotarse" una sola vez.

   USO
     Cronometro.iniciar({
         elemento: document.querySelector('.hud-reloj'),
         obtenerSegundos: () => Partida.segundosNivel(1),
         limite: CONFIG.TIEMPO_LIMITE_SEGUNDOS,
         alAgotarse: () => { ... }
     });
     Cronometro.detener();
     Cronometro.formatear(75) → "1:15"
   ========================================================================== */

const Cronometro = (function () {
    'use strict';

    let intervalo = null;
    let opciones = null;
    let agotado = false;

    function formatear(segundos) {
        const minutos = Math.floor(segundos / 60);
        const resto = segundos % 60;
        return minutos + ':' + String(resto).padStart(2, '0');
    }

    function actualizar() {
        const segundos = Math.min(opciones.obtenerSegundos(), opciones.limite);
        const tiempo = opciones.elemento.querySelector('[data-reloj-tiempo]');
        if (tiempo) {
            tiempo.textContent = formatear(segundos);
        }

        // Aviso visual en el último minuto
        const restantes = opciones.limite - segundos;
        opciones.elemento.classList.toggle('en-alerta', restantes <= CONFIG.AVISO_ULTIMOS_SEGUNDOS);

        if (segundos >= opciones.limite && !agotado) {
            agotado = true;
            detener();
            opciones.elemento.classList.add('agotado');
            if (opciones.alAgotarse) {
                opciones.alAgotarse();
            }
        }
    }

    function iniciar(nuevasOpciones) {
        detener();
        opciones = nuevasOpciones;
        agotado = false;
        const limite = opciones.elemento.querySelector('[data-reloj-limite]');
        if (limite) {
            limite.textContent = formatear(opciones.limite);
        }
        actualizar();
        // Se revisa 4 veces por segundo para que el cambio de número sea puntual
        if (!agotado) {
            intervalo = window.setInterval(actualizar, 250);
        }
    }

    function detener() {
        if (intervalo !== null) {
            window.clearInterval(intervalo);
            intervalo = null;
        }
    }

    return { iniciar, detener, formatear };
})();
