/* =============================================================================
   lupapoints.js — EL ÚNICO SISTEMA DE PUNTOS DEL JUEGO
   -----------------------------------------------------------------------------
   Los niveles suman, la pantalla final suma la bonificación y la tienda
   gasta: todos usan este módulo y la misma clave de guardado que ya tenía
   la tienda ("criminal_logic_lupapoints").

   Cada vez que el saldo cambia se emite el evento "lupapoints:cambio",
   que el marcador (js/ui/marcador.js) usa para actualizar la pantalla.

   USO
     Lupapoints.obtener()          → saldo actual
     Lupapoints.sumar(5000)        → nuevo saldo
     Lupapoints.gastar(3000)       → true si alcanzó; false si no (no descuenta)
     Lupapoints.formatear(12000)   → "12.000"
   ========================================================================== */

const Lupapoints = (function () {
    'use strict';

    const CLAVE = CONFIG.CLAVES.LUPAPOINTS;

    function obtener() {
        const saldo = Almacen.leerNumero(CLAVE, null);
        if (saldo === null || saldo < 0) {
            // Jugador nuevo: arranca con el saldo inicial
            guardar(CONFIG.PUNTOS_INICIALES);
            return CONFIG.PUNTOS_INICIALES;
        }
        return saldo;
    }

    function guardar(saldo) {
        const limpio = Math.max(0, Math.round(saldo));
        Almacen.guardarTexto(CLAVE, String(limpio));
        document.dispatchEvent(new CustomEvent('lupapoints:cambio', { detail: { saldo: limpio } }));
    }

    function sumar(cantidad) {
        guardar(obtener() + Math.max(0, cantidad));
        return obtener();
    }

    function gastar(cantidad) {
        const saldo = obtener();
        if (cantidad > saldo) {
            return false;
        }
        guardar(saldo - cantidad);
        return true;
    }

    function formatear(numero) {
        return Number(numero).toLocaleString('es-AR');
    }

    return { obtener, sumar, gastar, formatear };
})();
