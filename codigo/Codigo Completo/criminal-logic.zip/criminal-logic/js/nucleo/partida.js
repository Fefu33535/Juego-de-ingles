/* =============================================================================
   partida.js — REGLAS DE LA PARTIDA, PUNTOS Y EVALUACIÓN FINAL
   -----------------------------------------------------------------------------
   Una PARTIDA empieza cuando el jugador entra a un nivel y termina en la
   pantalla final, que llega por uno de estos motivos:
     • 'completado' → resolvió el último caso (nivel 3)
     • 'tiempo'     → el cronómetro de un nivel llegó al límite (10:00)
     • 'abandono'   → el jugador abandonó el caso desde el botón ✕

   Durante la partida se guarda:
     errores    → acusaciones equivocadas (sospechoso o contradicción mal)
     resueltos  → casos resueltos en esta partida
     intentos   → hora de inicio del reloj de cada nivel en juego. Se guarda
                  en el navegador para que recargar la página NO reinicie el reloj.

   USO
     Partida.empezarNivel(n)        → arranca (o retoma) el reloj del nivel n
     Partida.segundosNivel(n)       → segundos transcurridos en el nivel n
     Partida.registrarError(n)
     Partida.resolverNivel(n)       → { puntos, esUltimo }  (suma Lupapoints y desbloquea)
     Partida.terminar(motivo, n)    → evalúa, guarda el resultado y limpia la partida
     Partida.actual()               → datos de la partida en curso (o null)
     Partida.ultimoResultado()      → lo que muestra final.html
   ========================================================================== */

const Partida = (function () {
    'use strict';

    const CLAVES = CONFIG.CLAVES;

    /* -------------------------------------------------------------------------
       Lectura y escritura de la partida en curso
       ---------------------------------------------------------------------- */
    function actual() {
        return Almacen.leerJSON(CLAVES.PARTIDA, null);
    }

    function guardar(partida) {
        Almacen.guardarJSON(CLAVES.PARTIDA, partida);
    }

    function nueva() {
        return {
            inicio: Date.now(),
            errores: 0,
            resueltos: [],      // números de nivel resueltos en esta partida
            tiempos: {},        // segundos que tardó en cada nivel resuelto
            puntosNiveles: 0,   // Lupapoints ganados por resolver casos
            intentos: {}        // { "2": horaDeInicio } niveles con el reloj corriendo
        };
    }

    function obtenerOCrear() {
        return actual() || nueva();
    }

    /* -------------------------------------------------------------------------
       Reloj de cada nivel
       ---------------------------------------------------------------------- */
    function empezarNivel(numero) {
        const partida = obtenerOCrear();
        // Si el reloj de este nivel ya estaba corriendo (recarga, botón Atrás),
        // se respeta la hora original: el tiempo no vuelve a 0:00.
        if (!partida.intentos[numero]) {
            partida.intentos[numero] = Date.now();
        }
        guardar(partida);
    }

    function segundosNivel(numero) {
        const partida = actual();
        if (!partida || !partida.intentos[numero]) {
            return 0;
        }
        return Math.max(0, Math.floor((Date.now() - partida.intentos[numero]) / 1000));
    }

    function nivelEnJuego(numero) {
        const partida = actual();
        return Boolean(partida && partida.intentos[numero]);
    }

    /* -------------------------------------------------------------------------
       Errores y casos resueltos
       ---------------------------------------------------------------------- */
    function registrarError(numero) {
        const partida = obtenerOCrear();
        if (!partida.intentos[numero]) {
            return;                      // el nivel ya terminó: no cuenta
        }
        partida.errores += 1;
        guardar(partida);
    }

    function nivelesCobrados() {
        return Almacen.leerJSON(CLAVES.NIVELES_COBRADOS, []);
    }

    /**
     * El jugador acertó sospechoso y contradicción.
     * Detiene el reloj del nivel, lo desbloquea en el progreso y paga
     * los Lupapoints (solo la primera vez si PUNTOS_SOLO_PRIMERA_VEZ = true).
     */
    function resolverNivel(numero) {
        const partida = obtenerOCrear();
        const esUltimo = numero >= CONFIG.TOTAL_NIVELES;

        if (!partida.intentos[numero]) {
            return { puntos: 0, esUltimo, repetido: true };   // ya se había resuelto
        }

        partida.tiempos[numero] = segundosNivel(numero);
        delete partida.intentos[numero];
        if (partida.resueltos.indexOf(numero) === -1) {
            partida.resueltos.push(numero);
        }

        // Desbloqueo permanente del nivel siguiente
        Progreso.completarNivel(numero);

        // Bonificación de Lupapoints
        const cobrados = nivelesCobrados();
        let puntos = 0;
        if (!CONFIG.PUNTOS_SOLO_PRIMERA_VEZ || cobrados.indexOf(numero) === -1) {
            puntos = CONFIG.PUNTOS_POR_NIVEL;
            Lupapoints.sumar(puntos);
            partida.puntosNiveles += puntos;
            if (cobrados.indexOf(numero) === -1) {
                cobrados.push(numero);
                Almacen.guardarJSON(CLAVES.NIVELES_COBRADOS, cobrados);
            }
        }

        guardar(partida);
        return { puntos, esUltimo, repetido: puntos === 0 };
    }

    /* -------------------------------------------------------------------------
       Evaluación final
       ---------------------------------------------------------------------- */
    function calcularNota(partida, completo) {
        if (completo) {
            return Math.max(1, CONFIG.NOTA_MAXIMA - partida.errores);
        }
        // Objetivos sin cumplir: la nota nunca llega a aprobar
        return Math.min(CONFIG.NOTA_APROBACION - 1, 1 + partida.resueltos.length);
    }

    /**
     * Termina la partida, calcula la nota, paga el bono si corresponde
     * y deja guardado el resultado para que lo muestre final.html.
     */
    function terminar(motivo, numeroNivel) {
        const partida = obtenerOCrear();

        // Tiempo total: niveles resueltos + el nivel interrumpido (si lo hay)
        let segundosTotales = Object.values(partida.tiempos).reduce((a, b) => a + b, 0);
        if (numeroNivel && partida.intentos[numeroNivel]) {
            segundosTotales += Math.min(segundosNivel(numeroNivel), CONFIG.TIEMPO_LIMITE_SEGUNDOS);
        }

        const completo = motivo === 'completado' &&
            Progreso.obtenerUltimoCompletado() >= CONFIG.TOTAL_NIVELES;
        const nota = calcularNota(partida, completo);
        const aprobado = completo && nota >= CONFIG.NOTA_APROBACION;

        let bono = 0;
        let bonoYaCobrado = false;
        if (aprobado) {
            bonoYaCobrado = CONFIG.BONO_SOLO_UNA_VEZ && Almacen.leerTexto(CLAVES.BONO_COBRADO) === 'true';
            if (!bonoYaCobrado) {
                bono = nota * CONFIG.BONO_POR_PUNTO_DE_NOTA;
                Lupapoints.sumar(bono);
                Almacen.guardarTexto(CLAVES.BONO_COBRADO, 'true');
            }
        }

        const resultado = {
            motivo,
            nivel: numeroNivel || null,
            completo,
            aprobado,
            nota,
            errores: partida.errores,
            resueltos: partida.resueltos.length,
            segundosTotales,
            puntosNiveles: partida.puntosNiveles,
            bono,
            bonoYaCobrado,
            saldoFinal: Lupapoints.obtener(),
            fecha: Date.now()
        };

        Almacen.guardarJSON(CLAVES.RESULTADO, resultado);
        Almacen.borrar(CLAVES.PARTIDA);          // la próxima partida empieza de cero
        return resultado;
    }

    function ultimoResultado() {
        return Almacen.leerJSON(CLAVES.RESULTADO, null);
    }

    return {
        actual, empezarNivel, segundosNivel, nivelEnJuego, registrarError,
        resolverNivel, terminar, ultimoResultado
    };
})();
