/* =============================================================================
   progreso.js — DESBLOQUEO PERMANENTE DE NIVELES
   -----------------------------------------------------------------------------
   REGLA: el nivel 1 siempre está abierto. Cada nivel siguiente se abre para
   siempre cuando el anterior se resuelve correctamente. No se pueden saltear
   niveles y el progreso nunca retrocede.

   USO
     Progreso.obtenerUltimoCompletado()  → 0, 1, 2 o 3
     Progreso.estaCompletado(1)          → true / false
     Progreso.estaDesbloqueado(2)        → true / false
     Progreso.completarNivel(1)          → true si el progreso avanzó
     Progreso.rutaNivel(2)               → "nivel.html?n=2"
     Progreso.irANivel(2)                → abre el nivel si está desbloqueado
     Progreso.irAlSelector()
     Progreso.exigirDesbloqueo(3)        → si está bloqueado, vuelve al selector
     Progreso.reiniciar()                → borra el progreso (para probar)
   ========================================================================== */

const Progreso = (function () {
    'use strict';

    const CLAVE = CONFIG.CLAVES.PROGRESO;
    const TOTAL = CONFIG.TOTAL_NIVELES;

    function esNumeroDeNivel(numero) {
        return Number.isInteger(numero) && numero >= 1 && numero <= TOTAL;
    }

    function obtenerUltimoCompletado() {
        const numero = Almacen.leerNumero(CLAVE, 0);
        return Math.min(Math.max(numero, 0), TOTAL);
    }

    function estaCompletado(numero) {
        return esNumeroDeNivel(numero) && numero <= obtenerUltimoCompletado();
    }

    // Un nivel está desbloqueado si es el 1 o si el anterior ya fue resuelto
    function estaDesbloqueado(numero) {
        return esNumeroDeNivel(numero) && numero <= obtenerUltimoCompletado() + 1;
    }

    function completarNivel(numero) {
        if (!estaDesbloqueado(numero) || numero <= obtenerUltimoCompletado()) {
            return false;
        }
        Almacen.guardarTexto(CLAVE, String(numero));
        return true;
    }

    function rutaNivel(numero) {
        return CONFIG.RUTAS.nivel + '?n=' + numero;
    }

    function irANivel(numero) {
        if (!estaDesbloqueado(numero)) {
            return false;
        }
        window.location.href = rutaNivel(numero);
        return true;
    }

    function irAlSelector() {
        window.location.href = CONFIG.RUTAS.selector;
    }

    function exigirDesbloqueo(numero) {
        if (!estaDesbloqueado(numero)) {
            window.location.replace(CONFIG.RUTAS.selector);
            return false;
        }
        return true;
    }

    function reiniciar() {
        Almacen.borrar(CLAVE);
    }

    return {
        obtenerUltimoCompletado, estaCompletado, estaDesbloqueado, completarNivel,
        rutaNivel, irANivel, irAlSelector, exigirDesbloqueo, reiniciar
    };
})();
