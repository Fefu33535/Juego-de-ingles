/* =============================================================================
   sesion.js — SESIÓN DEL JUGADOR
   -----------------------------------------------------------------------------
   Recuerda si el jugador inició sesión. Las páginas internas (menú, niveles,
   tienda...) llaman a Sesion.exigir() al cargar: si nadie inició sesión,
   vuelven a la pantalla de inicio.

   USO
     Sesion.iniciar('ejemplo@alu.bue.edu.ar')
     Sesion.estaActiva()     → true / false
     Sesion.usuario()        → email guardado
     Sesion.nombreCorto()    → parte del email antes de la @
     Sesion.exigir()         → si no hay sesión, redirige a index.html
     Sesion.cerrar()         → cierra sesión (el progreso y los puntos se conservan)
   ========================================================================== */

const Sesion = (function () {
    'use strict';

    const CLAVES = CONFIG.CLAVES;

    function iniciar(usuario) {
        Almacen.guardarTexto(CLAVES.SESION_ACTIVA, 'true');
        Almacen.guardarTexto(CLAVES.USUARIO, usuario);
    }

    function estaActiva() {
        return Almacen.leerTexto(CLAVES.SESION_ACTIVA) === 'true';
    }

    function usuario() {
        return Almacen.leerTexto(CLAVES.USUARIO) || '';
    }

    function nombreCorto() {
        return usuario().split('@')[0] || 'detective';
    }

    function exigir() {
        if (!estaActiva()) {
            // replace: el botón "Atrás" no vuelve a la página protegida
            window.location.replace(CONFIG.RUTAS.inicio);
            return false;
        }
        return true;
    }

    function cerrar() {
        Almacen.borrar(CLAVES.SESION_ACTIVA);
    }

    return { iniciar, estaActiva, usuario, nombreCorto, exigir, cerrar };
})();
