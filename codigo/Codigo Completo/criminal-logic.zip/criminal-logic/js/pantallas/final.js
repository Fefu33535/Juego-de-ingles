/* =============================================================================
   final.js — PANTALLA FINAL: NOTA Y BONIFICACIÓN
   -----------------------------------------------------------------------------
   Muestra el resultado que calculó Partida.terminar() (js/nucleo/partida.js).
   Esta página solo muestra: los puntos ya se sumaron al terminar la partida,
   así que recargarla no vuelve a pagar nada.
   ========================================================================== */

(function () {
    'use strict';

    const resultado = Partida.ultimoResultado();

    if (!resultado) {
        document.getElementById('sin-resultado').hidden = false;
        return;
    }

    const $ = function (id) { return document.getElementById(id); };
    const erroresPermitidos = CONFIG.NOTA_MAXIMA - CONFIG.NOTA_APROBACION;

    // Título y motivo por el que terminó la partida
    const motivos = {
        completado: 'Resolviste los ' + CONFIG.TOTAL_NIVELES + ' casos.',
        tiempo: 'Se acabó el tiempo (' + Cronometro.formatear(CONFIG.TIEMPO_LIMITE_SEGUNDOS) + ') en el caso ' + resultado.nivel + '.',
        abandono: 'Abandonaste el caso ' + resultado.nivel + '.'
    };
    $('titulo-final').textContent = resultado.aprobado ? 'CASOS CERRADOS' : (resultado.completo ? 'CASOS CERRADOS CON ERRORES' : 'INVESTIGACIÓN INCOMPLETA');
    $('motivo-final').textContent = motivos[resultado.motivo] || '';

    // Nota y sello
    $('nota').textContent = resultado.nota;
    $('nota-maxima').textContent = CONFIG.NOTA_MAXIMA;
    $('estado-nota').textContent = resultado.aprobado ? 'APROBADO' : 'DESAPROBADO';
    document.querySelector('.informe').classList.add(resultado.aprobado ? 'es-aprobado' : 'es-desaprobado');

    // Detalle
    $('dato-resueltos').textContent = resultado.resueltos + ' de ' + CONFIG.TOTAL_NIVELES;
    $('dato-errores').textContent = resultado.errores;
    $('dato-tiempo').textContent = Cronometro.formatear(resultado.segundosTotales);
    $('dato-puntos').textContent = '+ ' + Lupapoints.formatear(resultado.puntosNiveles);
    $('dato-bono').textContent = resultado.bono > 0 ? '+ ' + Lupapoints.formatear(resultado.bono) : '0';

    // Mensaje según el desempeño
    let mensaje;
    if (resultado.aprobado && resultado.bono > 0) {
        mensaje = 'Buen trabajo, detective. Por tu nota ganaste una bonificación de ' +
            Lupapoints.formatear(resultado.bono) + ' Lupapoints.';
    } else if (resultado.aprobado) {
        mensaje = 'Buen trabajo, detective. La bonificación final ya la cobraste en una partida anterior.';
    } else if (resultado.completo) {
        mensaje = 'Resolviste los casos, pero con demasiados errores. Para aprobar y cobrar la bonificación ' +
            'necesitás ' + erroresPermitidos + ' errores o menos.';
    } else {
        mensaje = 'Sin bonificación. Para aprobar tenés que resolver los ' + CONFIG.TOTAL_NIVELES +
            ' casos, cada uno en menos de ' + Cronometro.formatear(CONFIG.TIEMPO_LIMITE_SEGUNDOS) +
            ', con ' + erroresPermitidos + ' errores o menos.';
    }
    $('mensaje-final').textContent = mensaje;

    $('informe').hidden = false;
})();
