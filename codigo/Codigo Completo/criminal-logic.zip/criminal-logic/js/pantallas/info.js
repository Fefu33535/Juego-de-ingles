/* =============================================================================
   info.js — PANTALLA DE INFORMACIÓN
   Muestra el progreso y permite reiniciar el juego (con confirmación).
   ========================================================================== */

(function () {
    'use strict';

    function mostrarCasos() {
        document.getElementById('dato-casos').textContent =
            Progreso.obtenerUltimoCompletado() + ' de ' + CONFIG.TOTAL_NIVELES;
    }

    document.getElementById('btn-reiniciar').addEventListener('click', function () {
        Modal.confirmar({
            titulo: '¿Reiniciar todo?',
            mensaje: 'Se borran los Lupapoints, los casos resueltos, las compras y el vestuario. No se puede deshacer.',
            aceptar: 'REINICIAR',
            cancelar: 'CANCELAR'
        }).then(function (acepto) {
            if (!acepto) {
                return;
            }
            const C = CONFIG.CLAVES;
            [C.LUPAPOINTS, C.COMPRAS, C.EQUIPADO, C.PROGRESO, C.NIVELES_COBRADOS,
                C.BONO_COBRADO, C.PARTIDA, C.RESULTADO].forEach(Almacen.borrar);
            Marcador.actualizar();          // vuelve a mostrar el saldo inicial
            mostrarCasos();
            Toast.mostrar('JUEGO REINICIADO', 'exito');
        });
    });

    mostrarCasos();
})();
