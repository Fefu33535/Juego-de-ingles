/* =============================================================================
   inicio-sesion.js — LÓGICA DE LA PANTALLA DE INICIO (index.html)
   ========================================================================== */

(function () {
    'use strict';

    /* Credenciales válidas (las mismas del proyecto original) */
    const USUARIO_CORRECTO = 'ejemplo@alu.bue.edu.ar';
    const PASSWORD_CORRECTA = '12345';

    const formulario = document.getElementById('form-login');
    const campoUsuario = document.getElementById('input-usuario');
    const campoPassword = document.getElementById('input-password');

    formulario.addEventListener('submit', function (evento) {
        evento.preventDefault();

        const usuario = campoUsuario.value.trim();
        const password = campoPassword.value.trim();

        if (usuario === USUARIO_CORRECTO && password === PASSWORD_CORRECTA) {
            Sesion.iniciar(usuario);
            Toast.mostrar('¡SESIÓN INICIADA CON ÉXITO!', 'exito', 1500);
            window.setTimeout(function () {
                window.location.href = CONFIG.RUTAS.menu;
            }, 1500);
        } else {
            Toast.mostrar('USUARIO O CONTRASEÑA INCORRECTOS', 'error');
            campoPassword.value = '';
            campoPassword.focus();
        }
    });
})();
