/* =============================================================================
   instrucciones.js — Completa los números de las reglas desde CONFIG
   ========================================================================== */

(function () {
    'use strict';

    const valores = {
        limite: Cronometro.formatear(CONFIG.TIEMPO_LIMITE_SEGUNDOS),
        puntos: Lupapoints.formatear(CONFIG.PUNTOS_POR_NIVEL),
        niveles: CONFIG.TOTAL_NIVELES,
        'nota-maxima': CONFIG.NOTA_MAXIMA,
        aprobacion: CONFIG.NOTA_APROBACION,
        bono: Lupapoints.formatear(CONFIG.BONO_POR_PUNTO_DE_NOTA)
    };

    document.querySelectorAll('[data-config]').forEach(function (elemento) {
        const clave = elemento.dataset.config;
        if (clave in valores) {
            elemento.textContent = valores[clave];
        }
    });
})();
