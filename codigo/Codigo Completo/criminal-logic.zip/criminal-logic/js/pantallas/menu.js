/* =============================================================================
   menu.js — MENÚ PRINCIPAL
   El botón SALIR pide confirmación y cierra la sesión (sin alert ni confirm).
   ========================================================================== */

(function () {
    'use strict';

    document.getElementById('btn-salir').addEventListener('click', function () {
        Modal.confirmar({
            titulo: '¿Cerrar sesión?',
            mensaje: 'Tus Lupapoints y los niveles desbloqueados quedan guardados.',
            aceptar: 'CERRAR SESIÓN',
            cancelar: 'VOLVER'
        }).then(function (acepto) {
            if (acepto) {
                Sesion.cerrar();
                window.location.href = CONFIG.RUTAS.inicio;
            }
        });
    });
})();
