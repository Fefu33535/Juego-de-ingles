/* =============================================================================
   selector.js — SELECTOR DE NIVELES
   -----------------------------------------------------------------------------
   Dibuja cada carpeta según el progreso guardado:
     desbloqueada → carpeta abierta, con su número, clickeable
     bloqueada    → carpeta con candado, deshabilitada
   ========================================================================== */

(function () {
    'use strict';

    const IMAGEN_ABIERTA = 'assets/images/selector/carpeta-abierta.png';
    const IMAGEN_CANDADO = 'assets/images/selector/carpeta-candado.png';

    function actualizarCarpetas() {
        document.querySelectorAll('.nivel-carpeta[data-nivel]').forEach(function (boton) {
            const nivel = Number(boton.dataset.nivel);
            const desbloqueado = Progreso.estaDesbloqueado(nivel);
            const completado = Progreso.estaCompletado(nivel);
            const imagen = boton.querySelector('img');

            boton.classList.toggle('desbloqueado', desbloqueado);
            boton.classList.toggle('bloqueado', !desbloqueado);
            boton.classList.toggle('completado', completado);
            // No se usa "disabled" para poder avisar con un cartel por qué está cerrada
            boton.setAttribute('aria-disabled', String(!desbloqueado));

            imagen.src = desbloqueado ? IMAGEN_ABIERTA : IMAGEN_CANDADO;
            imagen.alt = 'Nivel ' + nivel + (desbloqueado ? '' : ' bloqueado');

            // Número sobre la carpeta (solo si está abierta)
            let numero = boton.querySelector('.nivel-numero');
            if (desbloqueado && !numero) {
                numero = document.createElement('span');
                numero.className = 'nivel-numero';
                numero.setAttribute('aria-hidden', 'true');
                boton.querySelector('.carpeta').appendChild(numero);
            }
            if (numero) {
                numero.textContent = nivel;
                numero.hidden = !desbloqueado;
            }

            // Rótulo debajo de la carpeta
            let estado = boton.querySelector('.nivel-estado');
            if (!estado) {
                estado = document.createElement('span');
                estado.className = 'nivel-estado';
                boton.appendChild(estado);
            }
            // Dos renglones (\n) para que entre debajo de carpetas angostas
            estado.textContent = completado ? 'CASO ' + nivel + '\nRESUELTO'
                : desbloqueado ? 'CASO ' + nivel : 'BLOQUEADO';
        });
    }

    // Muestra cómo va la partida actual (lo que se evaluará en la pantalla final)
    function actualizarEstadoPartida() {
        const partida = Partida.actual();
        const texto = document.getElementById('estado-partida');
        if (!partida) {
            texto.hidden = true;
            return;
        }
        const resueltos = partida.resueltos.length;
        texto.textContent = 'Partida en curso: ' + resueltos + (resueltos === 1 ? ' caso resuelto' : ' casos resueltos') +
            ' · ' + partida.errores + (partida.errores === 1 ? ' error' : ' errores');
        texto.hidden = false;
    }

    // Un solo manejador de clics para las tres carpetas
    document.querySelector('.niveles-contenedor').addEventListener('click', function (evento) {
        const boton = evento.target.closest('.nivel-carpeta[data-nivel]');
        if (!boton) {
            return;
        }
        const nivel = Number(boton.dataset.nivel);
        if (!Progreso.irANivel(nivel)) {
            Toast.mostrar('RESOLVÉ EL CASO ' + (nivel - 1) + ' PARA DESBLOQUEARLO', 'error');
        }
    });

    function actualizarTodo() {
        actualizarCarpetas();
        actualizarEstadoPartida();
    }

    actualizarTodo();

    // Al volver con el botón "Atrás" del navegador se relee el progreso
    window.addEventListener('pageshow', function (evento) {
        if (evento.persisted) {
            actualizarTodo();
        }
    });
})();
