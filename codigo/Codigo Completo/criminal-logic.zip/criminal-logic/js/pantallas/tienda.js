/* =============================================================================
   tienda.js — TIENDA DE PUNTOS
   -----------------------------------------------------------------------------
   Usa el sistema de puntos del juego (Lupapoints) y la misma lista de
   compras que lee el vestidor ("criminal_logic_compras").
   ========================================================================== */

(function () {
    'use strict';

    const CLAVE_COMPRAS = CONFIG.CLAVES.COMPRAS;
    const MONEDA = 'assets/images/ui/lupapoint.png';

    function obtenerCompras() {
        const compras = Almacen.leerJSON(CLAVE_COMPRAS, []);
        return Array.isArray(compras) ? compras : [];
    }

    function registrarCompra(id) {
        const compras = obtenerCompras();
        if (compras.indexOf(id) === -1) {
            compras.push(id);
            Almacen.guardarJSON(CLAVE_COMPRAS, compras);
        }
    }

    // Dibuja el botón de cada tarjeta: precio con moneda, o COMPRADO
    function dibujarBoton(tarjeta) {
        const boton = tarjeta.querySelector('.boton-comprar');
        const precio = Number(tarjeta.dataset.precio);
        const comprado = obtenerCompras().indexOf(tarjeta.dataset.id) !== -1;

        boton.classList.toggle('comprado', comprado);
        boton.disabled = comprado;
        if (comprado) {
            boton.innerHTML = '<span class="boton-comprar-texto">COMPRADO</span>';
            boton.setAttribute('aria-label', 'Ya comprado');
        } else {
            boton.innerHTML = '<img class="boton-comprar-moneda" src="' + MONEDA + '" alt="">' +
                '<span class="boton-comprar-texto">' + Lupapoints.formatear(precio) + '</span>';
            boton.setAttribute('aria-label', 'Comprar por ' + Lupapoints.formatear(precio) + ' Lupapoints');
        }
    }

    function comprar(tarjeta) {
        const id = tarjeta.dataset.id;
        if (obtenerCompras().indexOf(id) !== -1) {
            return;
        }
        // gastar() descuenta solo si alcanza el saldo
        if (Lupapoints.gastar(Number(tarjeta.dataset.precio))) {
            registrarCompra(id);
            dibujarBoton(tarjeta);
        } else {
            Toast.mostrar('DINERO INSUFICIENTE', 'error');
        }
    }

    const tarjetas = document.querySelectorAll('.producto[data-id]');
    tarjetas.forEach(dibujarBoton);

    document.querySelector('.tienda-contenido').addEventListener('click', function (evento) {
        const boton = evento.target.closest('.boton-comprar');
        if (boton && !boton.disabled) {
            comprar(boton.closest('.producto'));
        }
    });

    // Al volver con "Atrás" (por ejemplo desde el vestidor) se refresca todo
    window.addEventListener('pageshow', function (evento) {
        if (evento.persisted) {
            tarjetas.forEach(dibujarBoton);
        }
    });
})();
