/* =============================================================================
   vestidor.js — VESTIDOR
   -----------------------------------------------------------------------------
   Muestra las prendas compradas en la tienda (criminal_logic_compras) y
   guarda lo que el jugador tiene puesto (criminal_logic_equipado).
   ========================================================================== */

(function () {
    'use strict';

    const CLAVES = CONFIG.CLAVES;

    // Prenda que se usa en cada categoría cuando no hay nada elegido
    const VESTUARIO_BASE = Object.freeze({
        sombrero: 'sombreroBase',
        abrigo: 'chaquetaBase',
        pantalon: 'pantalonBase',
        calzado: 'botasBase'
    });

    // Imagen del personaje según el calzado elegido
    const PERSONAJES = {
        base: 'assets/images/vestidor/personaje-base.png',
        cowShoes: 'assets/images/vestidor/personaje-cow-shoes.png'
    };

    let vestuarioActual = Object.assign({}, VESTUARIO_BASE);

    /* ------------------------------------------------------------------------- */
    function obtenerCompras() {
        const compras = Almacen.leerJSON(CLAVES.COMPRAS, []);
        return Array.isArray(compras) ? compras : [];
    }

    // Las prendas con data-requiere-compra solo aparecen si se compraron
    function mostrarPrendasCompradas() {
        const compras = obtenerCompras();
        document.querySelectorAll('.prenda[data-requiere-compra]').forEach(function (prenda) {
            prenda.classList.toggle('desbloqueada', compras.indexOf(prenda.dataset.id) !== -1);
        });
    }

    function marcarSeleccion() {
        document.querySelectorAll('.prenda').forEach(function (prenda) {
            const elegida = vestuarioActual[prenda.dataset.categoria] === prenda.dataset.id;
            prenda.classList.toggle('seleccionada', elegida);
            prenda.setAttribute('aria-pressed', String(elegida));
        });
    }

    function actualizarPersonaje() {
        document.getElementById('img-personaje').src =
            vestuarioActual.calzado === 'cowShoes' ? PERSONAJES.cowShoes : PERSONAJES.base;
    }

    function refrescar() {
        marcarSeleccion();
        actualizarPersonaje();
    }

    /* -------------------------------------------------------------------------
       Elegir prenda: tocar la elegida otra vez vuelve a la prenda base
       ---------------------------------------------------------------------- */
    function elegirPrenda(prenda) {
        if (!prenda.classList.contains('desbloqueada')) {
            return;
        }
        const categoria = prenda.dataset.categoria;
        const id = prenda.dataset.id;
        const base = VESTUARIO_BASE[categoria];

        vestuarioActual[categoria] = (vestuarioActual[categoria] === id && id !== base) ? base : id;
        refrescar();
    }

    function cargarGuardado() {
        const guardado = Almacen.leerJSON(CLAVES.EQUIPADO, null);
        if (guardado && typeof guardado === 'object') {
            vestuarioActual = Object.assign({}, VESTUARIO_BASE, guardado);
        }
        // Si se equipó algo que ya no figura como comprado, vuelve a la base
        const compras = obtenerCompras();
        document.querySelectorAll('.prenda[data-requiere-compra]').forEach(function (prenda) {
            const categoria = prenda.dataset.categoria;
            if (vestuarioActual[categoria] === prenda.dataset.id && compras.indexOf(prenda.dataset.id) === -1) {
                vestuarioActual[categoria] = VESTUARIO_BASE[categoria];
            }
        });
    }

    function guardar() {
        Almacen.guardarJSON(CLAVES.EQUIPADO, vestuarioActual);
        Toast.mostrar('GUARDADO CORRECTAMENTE', 'exito');
    }

    function resetear() {
        vestuarioActual = Object.assign({}, VESTUARIO_BASE);
        Almacen.borrar(CLAVES.EQUIPADO);
        refrescar();
        Toast.mostrar('VESTUARIO RESTABLECIDO', 'exito');
    }

    /* ------------------------------------------------------------------------- */
    document.querySelector('.armario').addEventListener('click', function (evento) {
        const prenda = evento.target.closest('.prenda');
        if (prenda) {
            elegirPrenda(prenda);
        }
    });
    document.getElementById('btn-guardar').addEventListener('click', guardar);
    document.getElementById('btn-resetear').addEventListener('click', resetear);

    mostrarPrendasCompradas();
    cargarGuardado();
    refrescar();
})();
