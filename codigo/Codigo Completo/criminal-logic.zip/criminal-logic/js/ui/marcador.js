/* =============================================================================
   marcador.js — MARCADOR GLOBAL DE LUPAPOINTS Y PERFIL
   -----------------------------------------------------------------------------
   Cualquier elemento con el atributo  data-lupapoints  muestra el saldo
   actual, y cualquiera con  data-usuario  muestra el nombre del jugador.
   Se actualizan solos cuando el saldo cambia o cuando se vuelve a la
   página con el botón "Atrás" del navegador.

   En el HTML:
     <span data-lupapoints>0</span>
     <span data-usuario></span>
   ========================================================================== */

const Marcador = (function () {
    'use strict';

    function actualizar() {
        const saldo = Lupapoints.formatear(Lupapoints.obtener());
        document.querySelectorAll('[data-lupapoints]').forEach(function (elemento) {
            elemento.textContent = saldo;
        });
        document.querySelectorAll('[data-usuario]').forEach(function (elemento) {
            elemento.textContent = Sesion.nombreCorto();
        });
    }

    document.addEventListener('lupapoints:cambio', actualizar);
    document.addEventListener('DOMContentLoaded', actualizar);
    window.addEventListener('pageshow', function (evento) {
        if (evento.persisted) {
            actualizar();
        }
    });

    return { actualizar };
})();
