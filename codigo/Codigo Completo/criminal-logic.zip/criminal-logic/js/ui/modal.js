/* =============================================================================
   modal.js — VENTANA DE CONFIRMACIÓN (reemplaza a confirm())
   -----------------------------------------------------------------------------
   Muestra una ficha en el centro de la pantalla con dos botones.
   Devuelve una Promesa: true si el jugador aceptó, false si canceló
   (también con la tecla Escape o tocando fuera de la ficha).

   USO
     Modal.confirmar({
         titulo: '¿Abandonar el caso?',
         mensaje: 'La partida termina y se evalúa.',
         aceptar: 'ABANDONAR',
         cancelar: 'SEGUIR JUGANDO'
     }).then(function (acepto) { ... });
   ========================================================================== */

const Modal = (function () {
    'use strict';

    function confirmar(opciones) {
        return new Promise(function (resolver) {
            const elementoConFoco = document.activeElement;

            const fondo = document.createElement('div');
            fondo.className = 'modal-fondo';
            fondo.innerHTML =
                '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">' +
                '  <h2 class="modal-titulo" id="modal-titulo"></h2>' +
                '  <p class="modal-mensaje"></p>' +
                '  <div class="modal-botones">' +
                '    <button type="button" class="boton-papel" data-respuesta="no"></button>' +
                '    <button type="button" class="boton-papel boton-papel-peligro" data-respuesta="si"></button>' +
                '  </div>' +
                '</div>';

            // textContent: el texto nunca se interpreta como HTML
            fondo.querySelector('.modal-titulo').textContent = opciones.titulo || '';
            fondo.querySelector('.modal-mensaje').textContent = opciones.mensaje || '';
            fondo.querySelector('[data-respuesta="no"]').textContent = opciones.cancelar || 'CANCELAR';
            fondo.querySelector('[data-respuesta="si"]').textContent = opciones.aceptar || 'ACEPTAR';

            function cerrar(respuesta) {
                document.removeEventListener('keydown', alPresionarTecla);
                fondo.remove();
                if (elementoConFoco && elementoConFoco.focus) {
                    elementoConFoco.focus();
                }
                resolver(respuesta);
            }

            function alPresionarTecla(evento) {
                if (evento.key === 'Escape') {
                    cerrar(false);
                }
            }

            fondo.addEventListener('click', function (evento) {
                const boton = evento.target.closest('[data-respuesta]');
                if (boton) {
                    cerrar(boton.dataset.respuesta === 'si');
                } else if (evento.target === fondo) {
                    cerrar(false);          // clic fuera de la ficha
                }
            });
            document.addEventListener('keydown', alPresionarTecla);

            document.body.appendChild(fondo);
            fondo.querySelector('[data-respuesta="no"]').focus();
        });
    }

    return { confirmar };
})();
