/* =============================================================================
   toast.js — NOTIFICACIÓN FLOTANTE (reemplaza a alert())
   -----------------------------------------------------------------------------
   Muestra un cartel arriba al centro durante unos segundos. Usa los mismos
   colores que ya tenían el inicio de sesión, la tienda y el vestidor.

   USO
     Toast.mostrar('DINERO INSUFICIENTE', 'error');
     Toast.mostrar('GUARDADO CORRECTAMENTE', 'exito');
   ========================================================================== */

const Toast = (function () {
    'use strict';

    let elemento = null;
    let temporizador = null;

    function obtenerElemento() {
        if (!elemento) {
            elemento = document.createElement('div');
            elemento.className = 'toast';
            elemento.setAttribute('role', 'status');
            elemento.setAttribute('aria-live', 'polite');
            document.body.appendChild(elemento);
        }
        return elemento;
    }

    /**
     * @param {string} texto
     * @param {'exito'|'error'} tipo
     * @param {number} duracion milisegundos visibles
     */
    function mostrar(texto, tipo, duracion) {
        const toast = obtenerElemento();
        toast.textContent = texto;
        toast.className = 'toast toast-' + (tipo || 'exito');

        // Se fuerza un reflow para que la transición se vea aunque se repita
        void toast.offsetWidth;
        toast.classList.add('toast-visible');

        window.clearTimeout(temporizador);
        temporizador = window.setTimeout(function () {
            toast.classList.remove('toast-visible');
        }, duracion || 2500);
    }

    return { mostrar };
})();
